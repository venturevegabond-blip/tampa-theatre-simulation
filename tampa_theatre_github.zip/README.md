# Tampa Theatre Board Simulation — MGT 431

A browser-based classroom simulation with generic board roles and strategic options, a 50-minute timer, curveballs, feasibility calculations, voting, and a pilot charter.

## Publish with GitHub Pages

1. Create a GitHub repository named `tampa-theatre-simulation`. For a standard free personal account, use a public repository.
2. Extract this ZIP on your computer.
3. In the repository, choose **Add file > Upload files**. Upload `index.html`, `README.md`, and `.nojekyll` into the repository root, then commit. Do not upload the ZIP itself or put index.html inside a nested folder. If Windows hides `.nojekyll`, the simulation can still be published with index.html and README.md.
4. Open **Settings > Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**. Choose `main` and `/(root)`, then Save.
6. Once deployment finishes, open the site URL shown in Pages settings. Its usual form is `https://YOUR-USERNAME.github.io/tampa-theatre-simulation/`.
7. Share that published website URL in Canvas. Students do not need GitHub accounts to visit the public site.

Official instructions: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site

## Student use

Open the website, assign generic board roles, and work through the five tabs. Use one device per board table for a common set of decisions. Each browser runs its own simulation; decisions and timers are not synchronized across devices.

At the end, use **Copy Charter** to copy the charter into a document, or **Print / Save PDF**, and submit the result to the Canvas assignment specified by your instructor. Check the saved document before closing the simulation. This app does not submit work to Canvas or collect results centrally. Do not rely on refreshing the page to restore your work; the existing code writes some charter data locally but does not restore it on startup.

## Running and editing

Open `index.html` in a browser to run locally, or publish it as above. Internet access is needed for Tailwind CSS, Chart.js, and Google Fonts. There is no build step, installation, API key, or backend.

All HTML, styling, and JavaScript are in `index.html`. Strategy definitions are in `OPTIONS_DATA`; role briefs are in `ROLES_DATA`; shocks are in `CURVEBALLS_DATA`. Review case figures and teaching assumptions before classroom use. Publishing the repository makes its source and teaching content publicly accessible.

## Validation

The inline JavaScript was checked with `node --check`. The package preserves the supplied simulation behavior; a full browser interaction test has not been performed for this packaging step.
